/*
 * Class to manage all of the beans and button handlers
 * Creator: Thomas
 */

package controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import beans.Product;
import beans.User;
import database.ProductDatabaseAccess;
import database.UserFunctions;

@ManagedBean
@ViewScoped
public class Controller 
{
	//EJB for the users account credentials and info
	@EJB
	public User user;
	
	//DatabaseAccess object
	UserFunctions userDB = new UserFunctions();

	
	//DB Object
	ProductDatabaseAccess prodDB = new ProductDatabaseAccess();
	
	//Button handler for the registration page
	public String onSubmit()
	{
		
		//If the user is not a duplicate, register it
		if (userDB.registerUser(user))
		{
			return "LoggedIn.xhtml";
		}
		
		//if registration fails, return login failed
		return "LoginFailed.xhtml";
	}
	
	//Button handler for the login page
	public String onLogin()
	{
		//If the user can be logged in, return success
		if (userDB.login(user))
		{
			return "LoggedIn.xhtml";
		}
		
		//else return failure
		return "LoginFailed.xhtml";
	}
	
	//Button handler for the product creation page
	public String onProductAdd()
	{
		//Create a product object from the text field values
		FacesContext context = FacesContext.getCurrentInstance();
		Product product = context.getApplication().evaluateExpressionGet(context, "#{product}", Product.class);
		
		//Send the product to the product created page
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("product", product);

		return "Index.xhtml";
		//return "ProductCreated.xhtml";	
	}
	
	//Button handler for the product update page
	public String onUpdateProd(Product product)
	{
		//Get the id of the updated product
		int id = this.prodDB.getID(product);
		
		//If the product exists, set the ejb
		if (id!=0)
		{
			//Send the id to the next page
			FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("id", id);
			
			//navigate to update pages
			return "ProductUpdate.xhtml";
		}
		
		//If the product doesn't exist, navigate to error page
		else return "ProductError.xhtml";
		
	}
	
	//Button handler for the product delete page
	public String onDeleteProd(Product product)
	{	
		//Get the id of the product to be deleted
		int id = this.prodDB.getID(product);
		
		//Delete the product if it exists
		if (id!=0)
		{
			//Delete the product and navigate to delete page
			this.prodDB.deleteProduct(id);
			
			return "ProductDelete.xhtml";
		}
		
		//If the product doesn't exist, navigate to error page
		else return "ProductError.xhtml";
	}

	//Button handler for the product view page
	public String onViewProd(Product product)
	{
		//Get the id of the product to be deleted
		int id = this.prodDB.getID(product);
		
		//If the product exists, show the view for it
		if (id!=0)
		{
			//Pass the product and id to the display page
			FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("prod", product);
			FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("id", id);
			
			//Navigate to display page
			return "DisplayProduct.xhtml";
		}
		
		//If the product doesn't exist, navigate to error page
		else return "ProductError.xhtml";
	}
	
	//Button handler for updating product
	public String updateProduct(Product product, int id)
	{		
		//if the product can be updated 
		if (this.prodDB.updateProduct(id, product))
		{
			//navigate to the success page
			return "UpdateSuccess.xhtml";
		}
		
		//If the update fails
		else 
		{
			//Pass error msg
			String error = "The product may not hold those values, they are either invalid or already in the database";
			FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("error", error);
			
			//Navigate to the error page
			return "ProductError.xhtml";
		}
	}
	
	//Getter for the user EJB
	public User getUser()
	{
		return this.user;
	}
	
	//Setter for the user EJB	
	public void setUser(User user)
	{
		this.user = user;
	}
}