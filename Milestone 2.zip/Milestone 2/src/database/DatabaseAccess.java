package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import beans.Product;
import beans.User;

//Class ideally only be making queries and returning raw result sets,
//But the code is simple enough to ignore this

//If this class only makes queries and returns lists of users, it only needs 2 methods
//Not happy that there are some sql statements inside this class and some not, but i dunno what to do
public class DatabaseAccess 
{
	
	private Connection getConnection()
	{
		Connection conn = null;
		String url= "jdbc:postgresql://localhost:5432/postgres";
		String username = "postgres";
		String password = "root";
		
		try {
			conn = DriverManager.getConnection(url, username, password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}
	
	public List<User> searchUsers(String sql) 
	{
		List<User> users = new ArrayList<User>();
		Connection conn = null;
		
		try {
			conn = this.getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				String firstName = rs.getString("first_name");
				String lastName = rs.getString("last_name");
				String email = rs.getString("email");
				String address = rs.getString("address");
				String phoneNum = rs.getString("phone_num");
				String username = rs.getString("username");
				String password = rs.getString("password");

				User user = new User(firstName, lastName, email, phoneNum, address, username, password);
				System.out.println("Users firstNAame is: " + firstName);
				users.add(user);
			}

		}

		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if (conn!= null)
			{
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return users;
	}
	
	public void addUser(User user)
	{
		String firstName = user.getFirstName();
		String lastName = user.getLastName();
		String email = user.getEmail();
		String address = user.getAddress();
		String phoneNum = user.getPhoneNum();
		String username = user.getUsername();
		String password = user.getPassword();
		
		String sql = "INSERT INTO testapp.USERS (first_name, last_name, email, address, phone_num, username, password)"
				+ "VALUES ( '" + firstName + "', '" + lastName + "', '" + email + "', '" + address + "', '" + phoneNum + "', '" 
				+ username + "', '" + password + "')";
				
		System.out.println(sql);
		
		Connection conn = null;
		
		try 
		{
			conn = this.getConnection();
			Statement stmt = conn.createStatement();
			
			stmt.executeUpdate(sql);
			
			System.out.println("The user was added");
		}
		catch (SQLException e)
		{
			System.out.println("The user could not be added");
			e.printStackTrace();
		}
		finally
		{
			if (conn!= null)
			{
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	
	
}
