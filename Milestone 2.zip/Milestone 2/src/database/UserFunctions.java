package database;

import java.util.ArrayList;
import java.util.List;

import beans.User;

public class UserFunctions 
{
	private DatabaseAccess db = new DatabaseAccess();
	
	//Method to add the user into the database
	public boolean registerUser(User user) 
	{
		//Find email and username
		String email = user.getEmail();
		String username = user.getUsername();
		
		//Craft sql
		String sql = "SELECT * FROM testapp.USERS WHERE email = '" + email + "' OR username = '" + username + "'";
		
		//If the database contains the user, return false
		System.out.println("SIZE IS: " + db.searchUsers(sql).size());
		if (db.searchUsers(sql).size()!=0)
		{
			return false;
		}
		
		//Add the user to the database and return true
		db.addUser(user);
		return true;
	}
	
	//TODO: The controller needs to check which of the boxes is filled, email or username
	//Can't login with your email, might add later
	public boolean login(User user)
	{
		//Craft sql statement 
		String username = user.getUsername();
		String password = user.getPassword();
		String sql = "SELECT * FROM testapp.USERS WHERE username = '" + username + "' AND password = '" + password + "'";
		
		//Query the database
		List<User> result = db.searchUsers(sql);
		
		//if there are no results
		if (result.size()!=1)
		{
			return false;
		}
		
		//If there is a result, reset the user var and return true
		user.copy(result.get(0));
		return true;
	}
	
}
