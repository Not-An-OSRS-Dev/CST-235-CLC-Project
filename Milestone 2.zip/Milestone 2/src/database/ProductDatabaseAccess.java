package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import beans.Product;

@ManagedBean
@ViewScoped
public class ProductDatabaseAccess
{	
	//Method to get a connection, used throughout the other methods
	private Connection getConn()
	{
		//Credentials
		String url =  "jdbc:postgresql://localhost:5432/postgres";
		String username = "postgres";
		String password = "root";
		
		//Create new connection var
		Connection con = null;
		
		//Try to connect to db
		try {
			con = DriverManager.getConnection(url, username, password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Return the connection
		return con;
	}
	
	//Method to query a sql
	//Used for queries that have result sets
	private List<Product> sqlQuery(String sql)
	{
		//Create connection object
		Connection conn = this.getConn();
		
		//Create list of products and product object
		List<Product> products = new ArrayList<Product>();
		Product product = null;
		
		try
		{
			//Create statement and result set
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			//Loop through result set
			while (rs.next())
			{
				//Find product fields
				String name = rs.getString("product_name");
				String desc = rs.getString("description");
				double price = rs.getDouble("price");
				int stock = rs.getInt("stock");
				String photo = rs.getString("photo");
				
				//Create new product and set fields
				product = new Product();
				product.setProdName(name);
				product.setDesc(desc);
				product.setPrice(price);
				product.setStock(stock);
				product.setPhoto(photo);
				
				//Add product to the list
				products.add(product);
			}
			//Close result set and statement
			rs.close();
			stmt.close();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		//If connection made, close it
		finally
		{
			try 
			{
				if (conn!=null)
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//Return list of products
		return products;
	}
	
	//Method to find a product by its id
	public Product getProduct(int id)
	{
		//Craft sql staetement
		String sql = "SELECT * FROM coastalsweets.PRODUCTS WHERE product_id = '" + id + "'";
		
		//Create list of products and call sql method
		List<Product> products = this.sqlQuery(sql);
		
		//If there is not exactly 1 result
		if (products.size()!=1)
		{
			//Return null
			return null;
		}
		
		//Else return the result
		else return products.get(0);
	}
	
	//Method to get all products in the db
	public List<Product> getAllProducts()
	{
		//Craft sql statement
		String sql = "SELECT * FROM coastalsweets.PRODUCTS";
		
		//Create list of products and query the db
		List<Product> products = this.sqlQuery(sql);
		
		//Return results
		return products;
	}
	
	//Method to delete a product based on id
	public boolean deleteProduct(int id)
	{
		//Craft sql statement
		String sql = "DELETE FROM coastalsweets.PRODUCTS WHERE product_id = '" + id + "'";
		
		//Create connection
		Connection conn = this.getConn();
		
		//Var to hold whether the item is deleted
		boolean success = false;
		
		
		try {
			//Create statement and run sql
			Statement stmt = conn.createStatement();
			int rowsUpdated = stmt.executeUpdate(sql);
			
			//If the row is deleted
			if (rowsUpdated > 0)
			{
				//Success is true
				success = true;
			}
			
			//Close the statement
			stmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//If a connection was made, close it
		finally
		{
			if (conn!=null)
			{
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		//Return whether the delete command was succcesful
		return success;
	}
	
	//Method to update a product based on id and new fields
	public boolean updateProduct(int id, Product product)
	{
		//Take new field values
		String name = product.getProdName();
		String desc = product.getDesc();
		double price = product.getPrice();
		int stock = product.getStock();
		String photo = product.getPhoto();
		
		//Craft sql statement
		String sql = "UPDATE coastalsweets.PRODUCTS SET (product_name, description, price, stock, photo) = ('" 
				+ name + "', '" + desc + "', '" + price + "', '" + stock + "', '" + photo + "') WHERE product_id = '" + id + "'";
		
		//Create connection
		Connection conn = this.getConn();
		
		//Var to hold success of command
		boolean success = false;
		
		try {
			//Create statement
			Statement stmt = conn.createStatement();
			
			//Query db
			int rowsUpdated = stmt.executeUpdate(sql);
			
			//If the update succeded, update var value
			if (rowsUpdated > 0)
			{
				success = true;
			}
				
			//Close the statement
			stmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//If there was a connection, close it
		finally
		{
			try 
			{
				if (conn!=null)
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		//Return whether the update was successful
		return success;
	}
	
	//Method to get the id of a given product, if it exists
	public int getID(Product product)
	{
		//Find the name of the product, this is a unique identifier
		String name = product.getProdName();
		
		//Craft sql statement
		String sql = "SELECT product_id FROM coastalsweets.PRODUCTS WHERE product_name = '" + name + "'";
		
		//Create connection
		Connection conn = this.getConn();
		
		//The id to be returned, 0 is default value
		int id = 0;
		
		try 
		{
		//Create statement and result set, then query the db	
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		
		//Loop through the result set (there should be only 1 val)
		while (rs.next()) 
		{
			//Get the id
			id = rs.getInt("product_id");
		}
		
		//Close the result set and the statement
		rs.close();
		stmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Return the id variable
		return id;
	}
	
	//Method to add a product, not implemented yet
	public boolean addProduct(Product product)
	{
		//TODO: Add product, return true if successful
		//return false otherwise
		return false;
	}
}
