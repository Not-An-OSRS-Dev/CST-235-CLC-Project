/*
 * Interface to allow stateless EJB user bean
 * not actually any code in here, maybe can be removed?
 * Creator: Thomas
 */

package beans;

import javax.ejb.Local;

@Local
public interface UserInterface
{	
}
