package beans;

import javax.ejb.Local;

@Local
public interface ProductInterface {

}
