package businessServices;

import javax.ejb.Local;

@Local
public interface BusinessInterface {

}
