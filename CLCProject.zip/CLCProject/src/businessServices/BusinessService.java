package businessServices;

import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;

import beans.User;
import database.ProductDatabaseAccess;
import database.UserFunctions;

@Stateless
@Alternative
@Local(BusinessInterface.class)
@LocalBean
public class BusinessService implements BusinessInterface {

	private ProductDatabaseAccess prodDB = new ProductDatabaseAccess();
	private UserFunctions userDB = new UserFunctions();
	private User user;
	
	public BusinessService() {
		// TODO Auto-generated constructor stub
	}
	
	public ProductDatabaseAccess getProdDB() {
		return prodDB;
	}

	public void setProdDB(ProductDatabaseAccess prodDB) {
		this.prodDB = prodDB;
	}

	public UserFunctions getUserDB() {
		return userDB;
	}

	public void setUserDB(UserFunctions userDB) {
		this.userDB = userDB;
	}
	
	public User getUser()
	{
		return user;
	}
	
	public void setUser(User user)
	{
		this.user = user;
	}
}
