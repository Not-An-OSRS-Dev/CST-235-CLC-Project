/*
 * Class to manage all of the beans and button handlers
 * Creator: Thomas
 */

package controllers;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import beans.Product;
import beans.User;
import businessServices.BusinessService;

@ManagedBean
@ViewScoped
public class Controller 
{
	//BusinessService
	@Inject
	BusinessService service;
	
	//Button handler for the registration page
	public String onRegister()
	{
		//If the user is not a duplicate, register it
		if (service.getUserDB().registerUser(service.getUser()))
		{
			return "LoggedIn.xhtml";
		}
		
		//if registration fails, return login failed
		String error = "This user is already registered";
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("error", error);
		return "LoginFailed.xhtml";
	}
	
	//Method to logoff and return to index page
	public String logoff()
	{
		this.service.setUser(new User());
		return "Index.xhtml";
	}
	
	//Button handler for the login page
	public String onLogin()
	{
		//If the user can be logged in, return success
		if (service.getUserDB().login(service.getUser()))
		{
			return "LoggedIn.xhtml";
		}
		
		//else return failure
		String error = "Login Credentials Failed";
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("error", error);
		return "LoginFailed.xhtml";
	}
	
	//Button handler for the product creation page
	public String onProductAdd(Product product)
	{
		//Insert prod in Database
		if (this.service.getProdDB().addProduct(product))
		{
			//return "Product Created page" if successful;
			String successCode = product.getProdName() + " was created";
			FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("successCode", successCode);
			return "prodCommandSuccess.xhtml";	
		}
		
		//Retrun the error page if the product isn't created
		else 
		{
			//Create error message to pass to error page
			String error = "The product may not hold those values, they are either invalid or already in the database";
			FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("error", error);
			return "ProductError.xhtml";
		}
	}
	
	//Button handler for the product update page
	public String onUpdateProd(Product product)
	{
		//Get the id of the updated product
		int id = this.service.getProdDB().getID(product);
		
		//If the product exists, set the ejb
		if (id!=0)
		{
			//Send the id to the next page
			this.service.setProduct(product);
			FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("id", id);
			//navigate to update pages
			return "ProductUpdate.xhtml";
		}
		
		//If the product doesn't exist, navigate to error page
		else return "ProductError.xhtml";
		
	}
	
	//Button handler for the product delete page
	public String onDeleteProd(Product product)
	{	
		//Get the id of the product to be deleted
		int id = this.service.getProdDB().getID(product);
		
		//Delete the product if it exists
		if (id!=0)
		{
			//Delete the product and navigate to delete page
			this.service.getProdDB().deleteProduct(id);
			String successCode = product.getProdName() + " was deleted";
			FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("successCode", successCode);
			return "prodCommandSuccess.xhtml";
		}
		
		//If the product doesn't exist, navigate to error page
		else return "ProductError.xhtml";
	}

	//Button handler for the product view page
	public String onViewProd(Product product)
	{
		//Get the id of the product to be deleted
		int id = this.service.getProdDB().getID(product);
		
		//If the product exists, show the view for it
		if (id!=0)
		{
			//Pass the product and id to the display page
			FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("prod", product);
			FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("id", id);
			
			//Navigate to display page
			return "DisplayProduct.xhtml";
		}
		
		//If the product doesn't exist, navigate to error page
		else return "ProductError.xhtml";
	}
	
	//Button handler for updating product
	public String updateProduct(int id)
	{		
		//if the product can be updated 
		if (this.service.getProdDB().updateProduct(id, this.service.getProduct()))
		{
			//navigate to the success page
			String successCode = this.service.getProduct().getProdName() + " was updated";
			this.service.setProduct(new Product());
			FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("successCode", successCode);
			return "prodCommandSuccess.xhtml";
		}
		
		//If the update fails
		else 
		{
			//Pass error msg
			this.service.setProduct(new Product());
			String error = "The product may not hold those values, they are either invalid or already in the database";
			FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("error", error);
			
			//Navigate to the error page
			return "ProductError.xhtml";
		}
	}
	
	public BusinessService getService()
	{
		return service;
	}
	
	public void setService(BusinessService service)
	{
		this.service = service;
	}
}