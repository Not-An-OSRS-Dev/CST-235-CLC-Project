package businessServices;

import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import beans.Product;
import beans.User;

@RequestScoped
@Path("/json")
@Produces({ "application/xml", "application/json" })
@Consumes({ "application/xml", "application/json" })
public class REST_Service {

	@Inject 
	BusinessService service;	
	
	@GET
	@Path("/getproducts")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> getProducts()
	{
		List<Product> products = this.service.getProdDB().getAllProducts();
		return products;
	}
	
	@GET
	@Path("/getusers")
	@Produces(MediaType.APPLICATION_JSON)
	public List<User> getUsers()
	{
		List<User> users = service.getUserDB().getAllUsers();
		return users;
	}
	

	//@Path("/getprodid")
    @GET
    @Path("/getprodid/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Product getProductByID(@PathParam("id") int id)
    {
        Product product = service.getProdDB().findById(id);
        return product;
    }
    
    @GET
    @Path("/createproduct/{product_name}/{description}/{price}/{stock}/{photo}")
    @Produces(MediaType.APPLICATION_JSON)
    public Product createProductJson(@PathParam("product_name") String name, @PathParam("description") String description, 
            @PathParam("price") Double price, @PathParam("stock") int stock, @PathParam("photo") String photo)
    {
    	Product temp = new Product();
    	temp.setProdName(name);
    	temp.setDesc(description);
    	temp.setPrice(price);
    	temp.setStock(stock);
    	temp.setPhoto(photo);
        service.getProdDB().addProduct(temp);
        int id = service.getProdDB().getID(temp);
        Product product = null;
        if (id!=0)
        {
        	product = service.getProdDB().getProduct(id);
        }
        return product;
    }
}
